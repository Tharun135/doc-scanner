# Test Document for Progress Loader

This is a test document to verify that our new progress loader works correctly. The document contains several sentences with different types of writing issues.

This sentence have a grammar error. The passive voice was used extensively throughout the document. There are many long sentences that could potentially be difficult for readers to understand and comprehend properly.

## Section Two

The document analysis should go through several stages:
1. Upload and validation
2. Content parsing 
3. Sentence extraction
4. Rule-based analysis
5. Report generation

We should see a nice animated progress bar with percentages and stage descriptions!
