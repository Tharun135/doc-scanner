import re
from app.utils import get_line_number
from app.utils import get_sentence_from_index

def check_special_characters(content, doc, suggestions):
    # Rule 1: Use 'and' instead of '&' unless part of a formal name
    ampersand_pattern = r'&'
    matches = re.finditer(ampersand_pattern, content)
    for match in matches:
        line_number = get_line_number(content, match.start())
        suggestions.append(f"Line {line_number}: Use 'and' instead of '&' unless it's part of a formal name.")
    
    # Rule 2: Proper use of ellipsis
    ellipsis_pattern = r'\.{3,}'
    matches = re.finditer(ellipsis_pattern, content)
    for match in matches:
        line_number = get_line_number(content, match.start())
        suggestions.append(f"Line {line_number}: Use an ellipsis (…) character instead of '{match.group()}'.")
    
    # Rule 3: Correct use of quotation marks
    # Ensure double quotation marks are used for UI string references
    # Exception: Single quotes can be used for admonitions like NOTICE, WARNING, CAUTION, and DANGER
    single_quote_pattern = r"'[^']*'"
    matches = re.finditer(single_quote_pattern, content)
    for match in matches:
        line_number = get_line_number(content, match.start())
        matched_text = match.group()

        # Check if the matched text is an admonition
        admonitions = ["NOTICE", "WARNING", "CAUTION", "DANGER"]
        if any(admonition in matched_text.upper() for admonition in admonitions):
            continue

        suggestions.append(f"Line {line_number}: Use double quotation marks for UI string references instead of single quotes.")
    
    # Rule 4: Avoid using apostrophes for plurals
    apostrophe_plural_pattern = r"\b\w+'s\b"
    matches = re.finditer(apostrophe_plural_pattern, content)
    for match in matches:
        word = match.group()
        if not word.lower() in ["it's", "he's", "she's", "who's", "that's", "let's"]:
            line_number = get_line_number(content, match.start())
            suggestions.append(f"Line {line_number}: Do not use an apostrophe to form plurals: '{word}'.")
    
    # Rule 5: Avoid nesting parentheses
    nested_parentheses_pattern = r'\([^\(\)]*\([^\(\)]*\)[^\(\)]*\)'
    matches = re.finditer(nested_parentheses_pattern, content)
    for match in matches:
        line_number = get_line_number(content, match.start())
        suggestions.append(f"Line {line_number}: Avoid nesting parentheses; consider rephrasing.")
    
    # Rule 6: Avoid using symbols in place of words
    # symbol_substitutions = {
    #    '@': 'at',
    #    '#': 'number',
    #    '%': 'percent',
    #    '+': 'plus',
    #    '=': 'equals',
    #    '<': 'less than',
    #    '>': 'greater than'
    #}
    #for symbol, word in symbol_substitutions.items():
    #    pattern = rf'\b\w*{re.escape(symbol)}\w*\b'
    #    matches = re.finditer(pattern, content)
    #    for match in matches:
    #        line_number = get_line_number(content, match.start())
    #        # Exempt '<' and '>' if they are part of HTML tags
    #        if symbol in ['<', '>']:
    #            tag_pattern = r'<[^>]*>'
    #            if re.search(tag_pattern, content[match.start()-1:match.end()+1]):
    #                continue
    #        suggestions.append(f"Line {line_number}: Avoid using '{symbol}' in place of words; spell out the word '{word}'.")
    
    # Rule 7: Currency symbols placement
    currency_pattern = r'(\b\d+(\.\d{1,2})?\s*(\$|€|£|¥))'
    matches = re.finditer(currency_pattern, content)
    for match in matches:
        line_number = get_line_number(content, match.start())
        suggestions.append(f"Line {line_number}: Place the currency symbol before the amount, e.g., '${match.group(1)}' should be formatted as '${match.group(1)}'.")
    
    # Rule 8: Identify and evaluate tables separately
    table_pattern = r'^\|.*\|\s*\n(\|[-:]+\|)+'
    matches = re.finditer(table_pattern, content, re.MULTILINE)
    for match in matches:
        line_number = get_line_number(content, match.start())
        suggestions.append(f"Line {line_number}: Table detected. Evaluate it separately.")

    pass