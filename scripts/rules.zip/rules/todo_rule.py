def check(content):
    """Check for TODO items in the content."""
    feedback = []
    start = content.find("TODO")
    while start != -1:
        end = start + len("TODO")
        feedback.append({
            "text": "TODO",
            "start": start,
            "end": end,
            "message": "Consider completing the TODO items in the document."
        })
        start = content.find("TODO", end)
    return feedback