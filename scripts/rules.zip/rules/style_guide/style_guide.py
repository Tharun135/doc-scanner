import re
from app.utils import get_line_number

def check_style_guide(content, doc, suggestions):
    # Rule 1: Basics - Enforce concise wording
    wordiness_patterns = [r'\bvery\b', r'\bquite\b', r'\babsolutely\b', r'\breally\b']
    for pattern in wordiness_patterns:
        matches = re.finditer(pattern, content, flags=re.IGNORECASE)
        for match in matches:
            line_number = get_line_number(content, match.start())
            suggestions.append(f"Line {line_number}: Consider removing '{match.group()}' for conciseness.")

    # Rule 2: Style - Maintain clarity and consistency
    unclear_phrases = [r'\butilize\b', r'\bprior to\b', r'\bendeavor\b']
    for pattern in unclear_phrases:
        matches = re.finditer(pattern, content, flags=re.IGNORECASE)
        for match in matches:
            line_number = get_line_number(content, match.start())
            suggestions.append(f"Line {line_number}: Consider replacing '{match.group()}' with a simpler alternative.")

    # Rule 3: Length - Keep sentences and titles concise
    # Identify and handle Markdown tables separately
    table_pattern = re.compile(r'^\|.*\|\s*\n(\|[-:]+\|)+', re.MULTILINE)
    table_matches = list(table_pattern.finditer(content))
    table_ranges = []

    # Store table start and end positions
    for table_match in table_matches:
        table_start = table_match.start()
        table_end = content.find('\n\n', table_start)
        if table_end == -1:
            table_end = len(content)
        table_ranges.append((table_start, table_end))

    # Check for long sentences outside of tables
    long_sentence_pattern = r'[^.!?]{100,}'
    matches = re.finditer(long_sentence_pattern, content)

    for match in matches:
        in_table = any(start <= match.start() <= end for start, end in table_ranges)
        if in_table:  # Skip sentences inside tables
            line_number = get_line_number(content, match.start())
            suggestions.append(f"Line {line_number}: Consider breaking long sentences into shorter ones for readability.")

    # Check for long cell content in tables
    for table_start, table_end in table_ranges:
        table_content = content[table_start:table_end]
        table_lines = table_content.split('\n')
        for line in table_lines:
            if line.startswith('|'):
                cells = line.split('|')
                for cell in cells:
                    if len(cell.strip()) > 100:
                        line_number = get_line_number(content, table_start + table_content.find(cell))
                        suggestions.append(f"Line {line_number}: Consider breaking long cell content into shorter parts for readability.")


    # Rule 4: Capitalization - Maintain consistency
    capitalization_patterns = [r'\blog in\b', r'\blog file\b', r'\bequipment\b']
    for pattern in capitalization_patterns:
        matches = re.finditer(pattern, content, flags=re.IGNORECASE)
        for match in matches:
            line_number = get_line_number(content, match.start())
            suggestions.append(f"Line {line_number}: Ensure proper capitalization for '{match.group()}'.")
    
    # Rule 5: Grammar and Vocabulary - Avoid redundancy
    redundant_phrases = {"end result": "Use 'result' instead.", "free gift": "Use 'gift' instead."}
    for phrase, message in redundant_phrases.items():
        pattern = rf'\b{phrase}\b'
        matches = re.finditer(pattern, content, flags=re.IGNORECASE)
        for match in matches:
            line_number = get_line_number(content, match.start())
            suggestions.append(f"Line {line_number}: {message}")

    # Rule 6: UI Terminology - Standardize terms
    ui_terms = {
        "press": "Use 'click' instead of 'press' for UI actions.",
        "mouse over": "Use 'hover' instead of 'mouse over'.",
        "equipments": "Use 'equipment' instead of 'equipments'."
    }
    for term, message in ui_terms.items():
        pattern = rf'\b{term}\b'
        matches = re.finditer(pattern, content, flags=re.IGNORECASE)
        for match in matches:
            line_number = get_line_number(content, match.start())
            suggestions.append(f"Line {line_number}: {message}")

    # Rule 7: Time-based vocabulary - Ensure clarity
    time_words = [r'\blast\b', r'\brecent\b', r'\blatest\b']
    for pattern in time_words:
        matches = re.finditer(pattern, content, flags=re.IGNORECASE)
        for match in matches:
            line_number = get_line_number(content, match.start())
            suggestions.append(f"Line {line_number}: Ensure '{match.group()}' is used correctly to indicate time.")

    # Rule 8: Numbers and Measurements - Standardize formatting
    number_pattern = r'\b([0-9]+) (seconds|minutes|hours|days)\b'
    matches = re.finditer(number_pattern, content)
    for match in matches:
        line_number = get_line_number(content, match.start())
        suggestions.append(f"Line {line_number}: Consider formatting numbers consistently, e.g., '5 minutes' instead of 'five minutes'.")

    # Rule 9: Error Messages - Keep them clear and actionable
    error_patterns = [r'\berror\b', r'\bfailure\b', r'\binvalid\b']
    for pattern in error_patterns:
        matches = re.finditer(pattern, content, flags=re.IGNORECASE)
        for match in matches:
            line_number = get_line_number(content, match.start())
            suggestions.append(f"Line {line_number}: Ensure error messages provide clear actions for users.")

    pass