> **NOTE**! This is important information.

This document has several exclamation marks! Some are in templates! Others are not!

> **WARNING**! Be careful with this operation.

Regular content follows. This sentence has no excessive punctuation.
