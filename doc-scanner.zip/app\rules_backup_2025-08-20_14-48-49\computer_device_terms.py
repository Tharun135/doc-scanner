import re
import spacy
from bs4 import BeautifulSoup
import html

# Import RAG system with fallback
try:
    from .rag_rule_helper import check_with_rag
    RAG_HELPER_AVAILABLE = True
except ImportError:
    RAG_HELPER_AVAILABLE = False
    import logging
    logging.debug(f"RAG helper not available for {__name__} - using basic rules")

# Load spaCy English model (make sure to run: python -m spacy download en_core_web_sm)
nlp = spacy.load("en_core_web_sm")

def check(content):
    suggestions = []

    # Strip HTML tags from content
    soup = BeautifulSoup(content, "html.parser")
    text_content = soup.get_text()

    # Define doc using nlp
    doc = nlp(text_content)
    
    # Rule 1: Use 'disk' for magnetic media and 'disc' for optical media
    disk_disc_matches = re.finditer(r'\bdisc\b', content, flags=re.IGNORECASE)
    for match in disk_disc_matches:
        suggestions.append("Ensure 'disc' is appropriate (use 'disk' for magnetic media and 'disc' for optical media).")

    # Rule 2: Use 'touchscreen' as one word
    touch_screen_matches = re.finditer(r'\btouch screen\b', content, flags=re.IGNORECASE)
    for match in touch_screen_matches:
        suggestions.append("Use 'touchscreen' as one word.")

    # Rule 3: Capitalize 'Internet' when used as a noun
    internet_matches = re.finditer(r'\binternet\b', content)
    for match in internet_matches:
        suggestions.append("Capitalize 'Internet' when used as a noun.")

    # Rule 4: Use 'email' without a hyphen
    email_matches = re.finditer(r'\be-mail\b', content, flags=re.IGNORECASE)
    for match in email_matches:
        suggestions.append("Use 'email' without a hyphen.")

    # Rule 5: Use 'USB flash drive' instead of 'USB drive' or 'flash drive' alone
    usb_drive_matches = re.finditer(r'\b(USB drive|flash drive)\b', content, flags=re.IGNORECASE)
    for match in usb_drive_matches:
        suggestions.append(f"Consider using 'USB flash drive' instead of '{match.group()}'.")

    # Rule 6: Use 'Ethernet' with a capital 'E'
    ethernet_matches = re.finditer(r'\bethernet\b', content)
    for match in ethernet_matches:
        suggestions.append("Capitalize 'Ethernet'.")

    # Rule 7: Use 'Wi-Fi' with a hyphen and capital 'W' and 'F'
    wifi_matches = re.finditer(r'\bwifi\b', content, flags=re.IGNORECASE)
    for match in wifi_matches:
        suggestions.append("Use 'Wi-Fi' with capital 'W' and 'F' and a hyphen.")

    # Rule 8: Use 'hardware' and 'software' as uncountable nouns (avoid 'hardwares' or 'softwares')
    hardwares_softwares_matches = re.finditer(r'\b(hardwares|softwares)\b', content, flags=re.IGNORECASE)
    for match in hardwares_softwares_matches:
        suggestions.append("Use 'hardware' and 'software' as uncountable nouns (do not pluralize).")

    # Rule 9: Use 'computer' instead of 'machine' when referring to computers
    machine_matches = re.finditer(r'\bmachine\b', content, flags=re.IGNORECASE)
    for match in machine_matches:
        suggestions.append("Consider using 'computer' instead of 'machine' when referring to computers.")

    # Rule 10: Use 'disk space' instead of 'storage space' when referring to disk capacity
    storage_space_matches = re.finditer(r'\bstorage space\b', content, flags=re.IGNORECASE)
    for match in storage_space_matches:
        suggestions.append("Use 'disk space' instead of 'storage space' when referring to disk capacity.")

    # Rule 11: Use 'laptop' instead of 'notebook' when referring to portable computers
    notebook_matches = re.finditer(r'\bnotebook\b', content, flags=re.IGNORECASE)
    for match in notebook_matches:
        suggestions.append("Use 'laptop' instead of 'notebook' when referring to portable computers.")

    # Rule 12: Use 'memory' for RAM and 'storage' for disk space
#    memory_storage_matches = re.finditer(r'\b(memory|storage)\b', content, flags=re.IGNORECASE)
#    for match in memory_storage_matches:
#        word = match.group().lower()
#        if word == 'memory':
#            suggestions.append("Use 'storage' instead of 'memory' when referring to disk space.")
#       elif word == 'storage':
#            suggestions.append("Use 'memory' instead of 'storage' when referring to RAM.")
#    
#    return suggestions if suggestions else []
